using System;

class Program{
    static void Main(){
        
        Console.WriteLine("Inserisci un numero: ");
        int num = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Numeri primi da 1 a " + num + " sono: ");
        for(int i = 2; i <= num; i++){
            bool isPrimo = true;
            for (int j = 2; j <= Math.Sqrt(i); j++){
                if (i % j == 0){
                    isPrimo = false;
                    break;
                }
            }

            if (isPrimo){
                Console.WriteLine(i);
            }
        }
    }
}