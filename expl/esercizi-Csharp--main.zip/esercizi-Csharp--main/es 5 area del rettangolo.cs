using System;

class Program{
    static void Main(){
        
        Console.WriteLine("Inserisci larghezza del rettangolo: ");
        double larghezza = Convert.ToDouble(Console.ReadLine());
        
        Console.WriteLine("Inserisci altezza del rettangolo: ");
        double altezza = Convert.ToDouble(Console.ReadLine());

        double area = larghezza * altezza;
        Console.WriteLine($"L'area del rettangolo e "+area);
    }
}
