using System;

class Program{
    static void Main(){
        
        Console.WriteLine("Inserisci un numero: ");
        int num = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine($"Tabellina del "+num);
        
        for (int i = 1; i <= 10; i++){
            int risultato = num * i;
            Console.WriteLine(num+"X"+i+"="+risultato);
        }
    }
}