using System;

class Program{
    static void Main(){
        Console.WriteLine("Inserisci una stringa: ");
        string input = Console.ReadLine();

        string senzaSpazi = input.Replace(" ", "");
        Console.WriteLine($"Stringa senza spazi:"+senzaSpazi);
    }
}

