using UnityEngine;
using UnityEngine.SceneManagement;


public class cambiascena : MonoBehaviour{

    void Start(){
       
    }
    
    void Update()
    {
      if(Input.GetMouseButtonDown(0)){
        SceneManager.LoadScene("gioco");
      }
        
    }
}
