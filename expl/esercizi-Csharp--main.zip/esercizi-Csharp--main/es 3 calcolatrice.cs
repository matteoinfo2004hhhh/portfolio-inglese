using System;

class Program{
    static void Main(){
        Console.WriteLine("Inserisci il primo numero: ");
        double num1 = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Inserisci l'operatore (+, -, *, /): ");
        char operatore = Convert.ToChar(Console.ReadLine());

        Console.WriteLine("Inserisci il secondo numero: ");
        double num2 = Convert.ToDouble(Console.ReadLine());

        double risultato = 0;
        switch (operatore){
            case '+':
                risultato = num1 + num2;
                break;
            case '-':
                risultato = num1 - num2;
                break;
            case '*':
                risultato = num1 * num2;
                break;
            case '/':
                risultato = num1 / num2;
                break;
            default:
                Console.WriteLine("Operatore non valido.");
                break;
        }

        Console.WriteLine($"Il risultato"+risultato);
    }
}
