using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Punti : MonoBehaviour
{
    public Text scoreText;
    private float scoreCount = 0f;

    void Start()
    {
        
    }

    void Update()
    {
        scoreCount += 1f;
        scoreText.text = "PUNTEGGIO:" + Mathf.Round(scoreCount);
    }
}