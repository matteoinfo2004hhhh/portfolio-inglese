using System;

class Program{
    static void Main(){
        Console.WriteLine("Inserisci un numero: ");
        int n = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine($"I numeri di Armstrong tra 1 e {n} sono: ");
        for (int i = 1; i <= n; i++){
            int numero = i;
            int sommaCifre = 0;
            int numeroCifre = (int)Math.Floor(Math.Log10(numero) + 1);

            while (numero > 0){
                int cifra = numero % 10;
                sommaCifre += (int)Math.Pow(cifra, numeroCifre);
                numero /= 10;
            }

            if (sommaCifre == i){
                Console.WriteLine(i);
            }
        }
    }
}
