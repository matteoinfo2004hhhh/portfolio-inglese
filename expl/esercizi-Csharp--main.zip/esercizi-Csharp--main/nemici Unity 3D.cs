using UnityEngine;
using UnityEngine.SceneManagement;

public class nemici : MonoBehaviour
{
    public float velocitaMovimento = 7f;
    public float distanza = 100f;

    void Update()
    {
        float movimentoX = Mathf.PingPong(Time.time * velocitaMovimento, distanza) - distanza / 2f;
        Vector3 nuovaPosizione = new Vector3(movimentoX, transform.position.y, transform.position.z);
        transform.position = nuovaPosizione;
    }


}
