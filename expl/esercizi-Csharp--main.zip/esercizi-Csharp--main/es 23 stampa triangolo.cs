using System;

class Program{
    static void Main(){
        Console.WriteLine("Inserisci l'altezza del triangolo: ");
        int altezza = Convert.ToInt32(Console.ReadLine());

        for (int i = 1; i <= altezza; i++){
            for (int j = 1; j <= i; j++){
                Console.Write("*");
            }
            Console.WriteLine();
        }
    }
}