using UnityEngine;

public class RuotaCamera : MonoBehaviour
{
    public Transform oggettoDaSeguire;
    public float raggio = 5f;
    public float sensibilitaMouse = 2f;

    void Update()
    {
        float inputMouseX = Input.GetAxis("Mouse X");
        float inputMouseY = Input.GetAxis("Mouse Y");

        float angoloDiRotazioneX = inputMouseX * sensibilitaMouse;
        float angoloDiRotazioneY = inputMouseY * sensibilitaMouse;

        transform.RotateAround(oggettoDaSeguire.position, Vector3.up, angoloDiRotazioneX);
        transform.RotateAround(oggettoDaSeguire.position, transform.right, -angoloDiRotazioneY);

        Vector3 posizioneCamera = oggettoDaSeguire.position - transform.forward * raggio;

        transform.position = posizioneCamera;

        transform.LookAt(oggettoDaSeguire);
    }
}