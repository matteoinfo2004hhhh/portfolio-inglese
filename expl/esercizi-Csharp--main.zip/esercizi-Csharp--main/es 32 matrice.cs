using System;

int[,] matrice = new int[10, 10];

for (int i = 0; i < matrice.GetLength(0); i++) {
  for (int j = 0; j < matrice.GetLength(1); j++) {
    matrice[i, j] = i + j;
  }
}

for (int i = 0; i < matrice.GetLength(0); i++) {
  for (int j = 0; j < matrice.GetLength(1); j++) {
    Console.WriteLine(matrice[i, j]);
  }
}