using System;

class Programa{
    static void Main(){
        Console.WriteLine("Ciao mondo");
    }
}
