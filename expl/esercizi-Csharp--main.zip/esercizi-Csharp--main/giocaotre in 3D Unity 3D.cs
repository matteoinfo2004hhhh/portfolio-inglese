using UnityEngine;
using UnityEngine.SceneManagement;

public class MovimentoGiocatore : MonoBehaviour
{
    public float velocitaMovimento = 6f;
    public float sensibilitaMouse = 2f;

    void Update()
    {
        float movimentoOrizzontale = Input.GetAxis("Horizontal");
        float movimentoVerticale = Input.GetAxis("Vertical");

        Vector3 movimento = new Vector3(movimentoOrizzontale, 0f, movimentoVerticale) * velocitaMovimento * Time.deltaTime;
        transform.Translate(movimento);

        Vector3 posizione = transform.position;
        posizione.y = Mathf.Clamp(posizione.y, 0.5f, 10f);
        transform.position = posizione;

        float rotazioneY = Input.GetAxis("Mouse X") * sensibilitaMouse;
        transform.Rotate(0f, rotazioneY, 0f);

    }


}