using System;

int[] vettore1 = { 1, 2, 3 };
int[] vettore2 = { 4, 5, 6 };
int prodottoScalare = 0;

for (int i = 0; i < 3; i++)
{
    prodottoScalare += vettore1[i] * vettore2[i];
}
Console.WriteLine(prodottoScalare);