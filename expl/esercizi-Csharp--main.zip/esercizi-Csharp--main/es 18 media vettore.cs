using System;

class Program{
    static void Main(){
        
        int[] array = { 1, 2, 3, 4, 5 };
        int somma = 0;

        foreach (int numero in array){
            somma += numero;
        }

        double media = (double)somma / array.Length;
        Console.WriteLine($"La media degli elementi nell'array e: "+media);
    }
}