const express = require('express');

const server = express()
  .use((req, res) => res.sendFile('/index.html', { root: __dirname }))
  .listen(3000, () => console.log('Listening on 3000'));
  
const { Server } = require('ws');
//dichiaro le variabili.
let tc = 0;
let i=0;
let num=0;
let chi=0;
let quale=0;
let cquale = 0;
clients=[];
colori=['blue','blue','red'];//dichiaro i colori per indicare i  clinet.
const ws_server = new Server({ server });

ws_server.on('connection', (ws) => { 
  quale++;
  ws.id=quale;
   console.log('New client connected!');
   ws.on('close', () => console.log('Client has disconnected!'));
   
   ws.on('message', function() {
     tc++;    
     cquale=ws.id; 
     if(cquale==1){//faccio 2 if per indicare il licnet che entra da 1 e 2. 
      num+=5;
     }
     if(cquale==2){
      num-=5;
     }
     console.log(tc); 
    });

    let position = {//posizione del id client.
      chi: ws.id
   }

});

setInterval(() => {//set interval per indicare la azione che svolge js in comandi id position.
  ws_server.clients.forEach((client) => {
    let position = {x: num, t: quale, colore: colori[cquale]}
    const data = JSON.stringify({'position': position});
    ws_server.clients.forEach((client) => {
    client.send(data);
  });
  });
}, 10);

